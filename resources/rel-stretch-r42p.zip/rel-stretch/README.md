# moOde audio player

Moode Audio Player is a derivative of the wonderful WebUI audio player client for MPD originally designed and coded by Andrea Coiutti and Simone De Gregori, and subsequently enhanced by early efforts from the RaspyFi/Volumio projects.

Tim Curtis © 2014

Release Notes https://github.com/moode-player/moode/blob/master/www/relnotes.txt<br>
Player Setup https://github.com/moode-player/moode/blob/master/www/setup.txt<br>
Moode OS Builder https://github.com/moode-player/mosbuild

## Other Resources
[moodeaudio.org](http://moodeaudio.org)\
[moOde Twitter feed](http://twitter.com/MoodeAudio)\
[Contributors](https://github.com/moode-player/moode/blob/master/www/CONTRIBS.html)
